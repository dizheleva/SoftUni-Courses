﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Parking
{
    public class Parking : Car
    {
        private HashSet<Car> data;
        public string Type { get; set; }
        public int Capacity { get; set; }
        public int Count => data.Count;

        private Parking()
        {
            data = new HashSet<Car>();
        }
        public Parking(string name, int capacity) : this()
        {
            Type = name;
            Capacity = capacity;
        }

        public void Add(Car car)
        {
            if (Capacity > data.Count)
            {
                data.Add(car);
            }
        }

        public bool Remove(string manufacturer, string model)
        {
            var playerIsRemoved = data.Any(p => p.Manufacturer == manufacturer && p.Model==model);
            if (playerIsRemoved)
            {
                data.Remove(data.First(p => p.Manufacturer == manufacturer && p.Model == model));
            }
            return playerIsRemoved;
        }

        public Car GetLatestCar()
        {
            return data.Any() ? data.First(p => p.Year == data.Select(car => car.Year).Max()) : null;
        }

        public Car GetCar(string manufacturer, string model)
        {
            return data.Any() ? data.First(p => p.Manufacturer == manufacturer && p.Model == model) : null;
        }
        public string GetStatistics()
        {
            var sb = new StringBuilder();
            sb.AppendLine($"The cars are parked in {Type}:");
            sb.AppendLine($"{string.Join(Environment.NewLine, data)}");

            return sb.ToString().TrimEnd();
        }
    }
}
