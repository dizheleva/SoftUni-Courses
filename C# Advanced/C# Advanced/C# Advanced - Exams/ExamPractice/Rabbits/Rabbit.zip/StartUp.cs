﻿using System.Linq;

namespace Rabbits
{
    using System;

    public class StartUp
    {
        public static void Main()
        {
            
        }
    }
}
