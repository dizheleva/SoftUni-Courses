﻿using System;

namespace Vehicles
{
    public abstract class Vehicle
    {
        protected Vehicle(double quantity, double consumption)
        {
            this.FuelQuantity = quantity;
            this.FuelConsumption = consumption;
        }

        protected abstract string VehicleType { get; }
        public double FuelQuantity { get; set; }
        public double FuelConsumption { get; set; }

        public virtual void Drive(double distance)
        {
            if (FuelQuantity - distance * FuelConsumption >= 0)
            {
                Console.WriteLine($"{this.VehicleType} travelled {distance} km");
                FuelQuantity -= distance * FuelConsumption;
            }
            else
            {
                Console.WriteLine($"{this.VehicleType} needs refueling");
            }
        }

        public abstract void Refuel(double litters);

        public string Report()
        {
            return $"{this.VehicleType}: {this.FuelQuantity:f2}";
        }
    }
}
