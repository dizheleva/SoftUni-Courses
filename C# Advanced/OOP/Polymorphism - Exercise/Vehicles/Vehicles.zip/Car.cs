﻿namespace Vehicles
{
    public class Car : Vehicle
    {
        public Car(double quantity, double consumption) : base(quantity, consumption+0.9)
        {
        }

        protected override string VehicleType => "Car";
        public override void Refuel(double litters)
        {
            FuelQuantity += litters;
        }
    }
}
