﻿using System;

namespace Vehicles
{
    public class StartUp
    {
        static void Main()
        {
            var carInput = Console.ReadLine().Split();
            var car = new Car(double.Parse(carInput[1]), double.Parse(carInput[2]));
            var truckInput = Console.ReadLine().Split();
            var truck = new Truck(double.Parse(truckInput[1]), double.Parse(truckInput[2]));
            var n = int.Parse(Console.ReadLine());
            for (var i = 0; i < n; i++)
            {
                var commandLine = Console.ReadLine().Split();
                var command = commandLine[0];
                var vehicle = commandLine[1];
                var parameter = double.Parse(commandLine[2]);
                switch (command)
                {
                    case "Drive":
                        switch (vehicle)
                        {
                            case "Car":
                                car.Drive(parameter);
                                break;
                            case "Truck":
                                truck.Drive(parameter);
                                break;
                        }
                        break;
                    case "Refuel":
                        switch (vehicle)
                        {
                            case "Car":
                                car.Refuel(parameter);
                                break;
                            case "Truck":
                                truck.Refuel(parameter);
                                break;
                        }
                        break;
                }
            }
            Console.WriteLine(car.Report());
            Console.WriteLine(truck.Report());
        }
    }
}
