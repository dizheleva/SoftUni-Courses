﻿using System.Buffers.Text;

namespace Vehicles
{
    public class Truck : Vehicle
    {
        public Truck(double quantity, double consumption) : base(quantity, consumption+1.6)
        {
        }

        protected override string VehicleType => "Truck";
        public override void Refuel(double litters) 
        {
            FuelQuantity += litters*0.95;
        }
    }
}
