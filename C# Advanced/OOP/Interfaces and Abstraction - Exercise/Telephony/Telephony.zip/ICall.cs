﻿using System;

namespace Telephony
{
    public interface ICall
    {
        void Call(string number);
    }
}
