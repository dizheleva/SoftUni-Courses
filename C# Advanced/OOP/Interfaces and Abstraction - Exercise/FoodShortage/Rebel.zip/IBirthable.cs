﻿namespace FoodShortage
{
    public interface IBirthable
    {
        public string Birthdate { get; set; }
    }
}