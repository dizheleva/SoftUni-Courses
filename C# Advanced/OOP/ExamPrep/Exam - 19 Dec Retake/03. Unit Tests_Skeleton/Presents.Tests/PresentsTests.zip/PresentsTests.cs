﻿using System.Collections.Generic;

namespace Presents.Tests
{
    using System;
    using NUnit.Framework;

    public class ComputerTests
    {
        private const string testPresentName = "MyPresent";
        private const double testMagic = 100;
        private Present testPresent;
        private const string anotherPresentName = "AnotherPresent";
        private const double anotherMagic = 50;
        private Present anotherPresent;
        private List<Present> testPresentList;
        private Bag testBag;

        [SetUp]
        public void Setup()
        {

            testPresent = new Present(testPresentName, testMagic);
            anotherPresent = new Present(anotherPresentName, anotherMagic);
            testPresentList = new List<Present>();
            testBag = new Bag();
        }

        [Test]
        public void ConstructorShouldCreateABag()
        {
            Assert.AreEqual(0, testBag.GetPresents().Count);
        }

        [Test]
        public void CreateMethodShouldAddPresent()
        {
            testPresentList.Add(testPresent);
            var result = $"Successfully added present {testPresent.Name}.";

            Assert.AreEqual(result, testBag.Create(testPresent));
        }

        [Test]
        public void CreateMethodShouldThrowExceptionWithNullValue()
        {
            Present nullPresent = null;

            Assert.Throws<ArgumentNullException>(() => testBag.Create(nullPresent), "Present is null");
        }

        [Test]
        public void CreateMethodShouldThrowExceptionWithExistingValue()
        {
            testBag.Create(testPresent);

            Assert.Throws<InvalidOperationException>(() => testBag.Create(testPresent), "This present already exists!");
        }

        [Test]
        public void RemoveMethodShouldRemovePresent()
        {
            testBag.Create(testPresent);
            var result = true;

            //Assert.AreEqual(0, testBag.GetPresents().Count);
            //CollectionAssert.AreEqual(testPresentList, testBag.GetPresents());
            Assert.AreEqual(result, testBag.Remove(testPresent));
        }

        [Test]
        public void GetPresentWithLeastMagicMethodShouldGetCorrectPresent()
        {
            testBag.Create(testPresent);
            testBag.Create(anotherPresent);
            var result = anotherPresent;

            Assert.AreEqual(result, testBag.GetPresentWithLeastMagic());
        }

        [Test]
        public void GetPresentShouldGiveCorrectPresent()
        {
            testBag.Create(testPresent);

            Assert.AreEqual(testPresent, testBag.GetPresent(testPresentName));
        }
    }
}
